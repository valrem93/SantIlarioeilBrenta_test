# workshop-oc.github.io
Website of the Workshop on Open Citations
